<?php
## CONFIG ##
include("connectiondb.php");

# LIST EMAIL ADDRESS
$recipient = "order@animationdok.com";

# SUBJECT (Subscribe/Remove)
$subject = "Banner Form Query";
// $ebpage = "App development";

# RESULT PAGE
$location = "/thankyou";

## FORM VALUES ##

# SENDER - WE ALSO USE THE RECIPIENT AS SENDER IN THIS SAMPLE
# DON'T INCLUDE UNFILTERED USER INPUT IN THE MAIL HEADER!
$sender = "support@animationdok.com";

# MAIL BODY
$subscriber_email = $_REQUEST['bEmail'];
$subscriber_subject = "Thankyou!! One of Our Consultant Will Get Back To you Shortly
";
$subscriber_email_data = file_get_contents('https://www.animationdok.com/email/queryFormThankyou.html');

if(isset($_REQUEST['hiddencapcha']) && $_REQUEST['hiddencapcha'] == "" ){
  if(isset($_REQUEST['bName']) && $_REQUEST['bName'] != "" 
  && isset($_REQUEST['bEmail']) && $_REQUEST['bEmail'] != "" 
  && isset($_REQUEST['bNumber']) && $_REQUEST['bNumber'] != ""){


$body .= "Name: ".$_REQUEST['bName']." \n";
$body .= "Email: ".$_REQUEST['bEmail']." \n";
$body .= "Number: ".$_REQUEST['bNumber']." \n";
$body .= "Message: ".$_REQUEST['bMessage']." \n";
$body .= "Page URL: ".$_REQUEST['blocationURL']." \n";

// $body .= "Page: ".$ebpage." \n";

if (mysqli_connect_errno()){  echo "Failed to connect to MySQL: " . mysqli_connect_error(); }
else{ $sql = 'insert into bannerForm (cust_name ,cust_email ,cust_phonenumber ,cust_message ,pageURL ) values ("'.$_REQUEST['bName'].'","'.$_REQUEST['bEmail'].'","'.$_REQUEST['bNumber'].'","'.$_REQUEST['bMessage'].'","'.$_REQUEST['blocationURL'].'")';
mysqli_query($con,$sql);
mysqli_close($con);
}

$headers = "From: " . $sender . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

# add more fields here if required
## SEND MESSGAE ##

mail( $recipient, $subject, $body,  "From: $sender" ) or die ("Mail could not be sent.");
mail( $subscriber_email, $subscriber_subject, $subscriber_email_data, $headers) or die ("Unable to send email to subscriber");

## SHOW RESULT PAGE ##
header( "Location: $location" );

 }

    
}

?>
