<div class="container">
  <div class="row packslider">
  
  <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Revamp logo <br>Package </h3>
                  <p class="">Logo Package</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$39.99 <span class="strike">$79.98</span></h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn"  onClick="location.href='order?pack=1'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li><strong>2</strong> Custom Logo Design Concepts by 2 Designers</li>
                  <li><strong>2</strong> Revisions</li>
                  <li><strong>48</strong> to 72 hours TAT</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Unique Design Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee*</li>
              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
            <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Startup logo <br>Package</h3>
                  <p class="">Logo Package</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$69.99 <span class="strike">$139.99</span></h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn"  onClick="location.href='order?pack=2'">Order Now</button>
            <div class="list-scroll">
               <ul class="details">
                   <li><strong>4</strong> Custom Logo Design Concepts</li>
                    <li>By <strong>2</strong> Designers</li>
                    <li>Unlimited Revisions</li>
                    <li><strong>48</strong> to 72 hours TAT</li>
                    <li><strong>100%</strong> Satisfaction Guarantee</li>
                    <li><strong>100%</strong> Unique Design Guarantee</li>
                    <li><strong>100%</strong> Money Back Guarantee*</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
            <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">Best Seller</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Proffesional Logo <br>Package</h3>
                  <p class="">Logo Package</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$119.99 <span class="strike">$239.98</span></h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn"  onClick="location.href='order?pack=3'">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                   <li>Unlimited Logo Design Concepts</li>
                  <li>By <strong>4</strong> Industry Based Designers</li>
                  <li><strong>UNLIMITED</strong> Revisions</li>
                  <li><strong>FREE</strong> MS Electronic Letterhead</li>
                  <li><strong>FREE</strong> Custom Stationery Design (Letterhead, Business Card,  Envelope)</li>
                  <li><strong>48</strong> to <strong>72</strong> hours TAT</li>
                  <li><strong>FREE</strong> File Formats (EPS, Ai, GIF, JPEG, PSD)</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Unique Design Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Identity Logo <br>Package</h3>
                  <p class="">Logo Package</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$169.99 <span class="strike">$339.98</span></h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn"  onClick="location.href='order?pack=4'">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                    <li>Unlimited Logo Design Concepts by 8 Designers</li>
                    <li>FREE Icon Design</li>
                    <li>FREE Unlimited Revisions</li>
                    <li>Turnaround time 2-3 business days</li>
                    <li>1 Stationery Design Set (Business card, Letterhead, Envelope &amp; Email Signature)</li>
                    
                    <li>100% Satisfaction Guarantee</li>
                    <li>100% Money Back Guarantee*</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Corporate Logo <br>Package</h3>
                  <p class="">Logo Package</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$219.99 <span class="strike">$439.98</span></h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn"  onClick="location.href='order?pack=5'">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                      <li><strong>UNLIMITED</strong> Logo Design Concepts</li>
                      <li>By <strong>6</strong> Award Winning Designers</li>
                      <li><strong>Free</strong> Icon Design</li>
                      <li><strong>FREE</strong> Custom Stationery Design (Letterhead, Business Card, Envelope, Invoice)</li>
                      <li>Double Side Flyer (OR) Bi-Fold Brochure</li>
                      <li><strong>FREE</strong> MS Electronic Letterhead</li>
                      <li>Email Signature Design</li>
                      <li>UNLIMITED Revisions</li>
                      <li>48 to 72 hours TAT</li>
                      <li><strong>100%</strong> Satisfaction Guarantee</li>
                      <li><strong>100%</strong> Unique Design Guarantee</li>
                      <li><strong>100%</strong> Money Back Guarantee</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Elite Logo <br>Package</h3>
                  <p class="">Logo Package</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$419.99 <span class="strike">$839.98</span></h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="location.href='order?pack=1'">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                      <li><strong>UNLIMITED</strong> Logo Design Concepts</li>
                      <li>By <strong>8</strong> Design Artist</li>
                      <li><strong>UNLIMITED</strong> Revisions</li>
                      <li><strong>2</strong> Stationary Design Sets</li>
                      <li><strong>FREE</strong> MS Word Letterhead</li>
                      <li><strong>Free</strong> Email Signature</li>
                      <li><strong>3</strong> Page Custom Website</li>
                      <li>Mobile Responsive</li>
                      <li><strong>2</strong> Stock Photos</li>
                      <li><strong>2</strong> Banner Designs</li>
                      <li>jQuery Slider</li>
                      <li>All Final Files Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>
                      <li><strong>100%</strong> Ownership Rights</li>
                      <li><strong>100%</strong> Satisfaction Guarantee</li>
                      <li><strong>100%</strong> Unique Design Guarantee</li>
                      <li><strong>100%</strong> Money Back Guarantee *</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>  
</div>
</div>