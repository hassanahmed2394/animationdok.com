
          <div class="row list">
            <div class="col-md-12">
            <div class="item text-center">
                <p class="counter">400</p>
                <p class="nan">+</p>
                <span>Branded documents</span>
            </div>
            <div class="item text-center">
                <p class="counter">1500</p>
                <p class="nan">+</p>
                <span>Logos & identity</span>
            </div>

            <div class="item text-center">
                <p class="counter">1200</p>
                <p class="nan">+</p>
                <span>Websites</span>
            </div>
            <div class="item text-center">
                <p class="counter">7319</p>
                <p class="nan">+</p>
                <span>Secs rendred</span>
            </div>
             <div class="item text-center">
                <p class="counter">5</p>
                <p class="nan">+</p>
                <span>years of experience</span>
            </div>
<!--            <div class="item text-center">-->
<!--                <p class="counter">20</p>-->
<!--                <p class="nan"></p>-->
<!--                <span>place on dribbble</span>-->
<!--            </div>-->
        </div>
</div>
