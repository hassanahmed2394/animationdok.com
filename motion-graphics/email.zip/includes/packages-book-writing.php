 <div class="container">
  <div class="row packslider">
 <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Book Cover Design </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$400.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=31'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Enjoy the benefits of working with a world-class firm at an affordable cost. Our talented ghostwriters are at your service with amazing discounts in ghostwriting pricing plans.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Premium Book Video </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$3,900.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=32'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Similar to a movie trailer advertising a film, this creative book preview grabs the attention of readers and builds your book’s awareness.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Author Website </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$900.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=33'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>The Internet is the fastest-growing marketplace for books, and online book sales are poised to surpass sales through traditional retail outlets.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Professional Audio Book</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$7,000.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=34'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Over the years, the demand for audiobooks has significantly increased because readers are now able to easily download books and listen to them while they are on the move.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Custom Book Illustration </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$500.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=35'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Our team of experienced in-house artists will work with you to produce a striking custom illustrations that will help your book stand out. </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Book Publishing</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$500.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=36'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>We offer a wide range of services for writers, authors and researchers, such as editing, copyediting, designing, and publishing.  </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Book Marketing</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$2,400.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn"  onClick="location.href='order?pack=37'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Our Digital Marketing Service uses a unique combination of services to introduce your book to potential online readers globally. </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Copyrights Certificate</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$900.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="location.href='order?pack=38'">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Become a certified published author and gain your well-deserved position among the best authors in the world. </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
    


 </div>
      </div>