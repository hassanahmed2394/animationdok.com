<div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/1.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/1.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/2.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/2.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/3.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/3.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/4.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/4.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/5.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/5.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/6.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/6.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/7.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/7.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/8.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/8.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/9.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/9.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/10.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/10.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/11.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/11.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/12.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/12.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/13.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/13.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/14.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/14.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/15.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/15.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/16.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/16.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/17.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/17.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/18.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/18.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/19.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/19.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                    <div class="app-item col-12 col-md-6">
                        <a data-fancybox href="assets/images/portfolio/branding/20.png" class="bg-container" style="background-image: url(assets/images/portfolio/branding/20.png)">
                            <div class="mask">
                                <div class="content black">
                                    <h2>Branding</h2><span>Graphic design</span>
                                    <div class="svg-wrap">
                                        <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#fff">
                                                    <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>