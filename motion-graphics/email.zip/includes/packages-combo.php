 <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Startup Combo <br> Package</h3>
                  <p class="">Startup</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$899.99 <span class="strike">$1799.99</span></h2>
            </div>
            <div class="packinner">
              <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p>
            </div>
            <button class="packbtn" onClick="order?pack=15">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li><strong>4</strong> Custom Logo Design by <strong>3</strong> Designers</li>
                  <li><strong>FREE</strong> Icon Design (Turn around time 15 Minutes)</li>
                  <li>Website with CMS / Admin Panel</li>
                  <li>Mobile Responsive</li>
                  <li>Team of Expert Designers &amp; Developers</li>
                  <li><strong>6</strong> Royalty Free Stock Images</li>
                  <li><strong>3</strong> Website Banner Designs</li>
                  <li><strong>FREE</strong> Google Friendly Sitemap</li>
                  <li>Complete W3C Certified HTML</li>
                  <li><strong>1</strong> Stationery Design Set (Business card, Letterhead &amp; Envelop)</li>
                  <li><strong>FREE</strong> 1 Year Domain &amp; Hosting</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee*</li>
                  <li>Turn around time <strong>15</strong> Hours</li>

              </ul>

            </div>
            </div>
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
            <p>Let's Create</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">Popular</p>
          <div class="">

            <div class="packhdbox">
                  <h3 >Professional Combo <br> Package</h3>
                  <p class="">Professional</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$1399.99 <span class="strike">$2799.99</span></h2>
            </div>
            <div class="packinner">
              <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p>
            </div>
            <button class="packbtn" onClick="order?pack=16">Order Now</button>
            <div class="list-scroll">
               <ul class="details">
                  <li><strong>6</strong> Custom Logo Design by <strong>4</strong> Designers</li>
                  <li><strong>FREE</strong> Icon Design (Turn around time 15 Minutes)</li>
                  <li>Unlimited Pages Website with Unique Design</li>
                  <li>CMS / Admin Panel</li>
                  <li>Mobile Responsive</li>
                  <li>Team of Expert Designers &amp; Developers</li>
                  <li><strong>8</strong> Royalty Free Stock Images</li>
                  <li><strong>5</strong> Website Banner Designs</li>
                  <li>Custom Forms</li>
                  <li>Search Engine Submission</li>
                  <li>Turn around time <strong>15</strong> Hours</li>
                  <li>Complete W3C Certified HTML</li>
                  <li><strong>1</strong> Stationery Design Set (Business card, Letterhead, Envelop &amp; Email Signature)</li>
                  <li>Social Media Designs (Facebook, Twitter, Youtube)</li>  
                  <li><strong>FREE</strong> Google Friendly Sitemap</li>
                  <li><strong>FREE</strong> 1 Year Domain &amp; Hosting</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee*</li>
                  <li>Turn around time <strong>15</strong> Hours</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
                <p>Let's Create</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Corporate Combo <br>Package</h3>
                  <p class="">Corporate</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$1499.99 <span class="strike">$2999.99</span></h2>
            </div>
            <div class="packinner">
              <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p>
            </div>
            <button class="packbtn" onClick="order?pack=17">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                  <li>Unlimited Logo Design Concepts by <strong>8</strong> Designers</li>
                  <li><strong>FREE</strong> Icon Design (Turn around time 15 Minutes)</li>
                  <li>Unlimited Pages Website with Custom Made Unique Design</li>
                  <li>Custom CMS / Backend Adminstrative System</li>
                  <li>Mobile Responsive</li>
                  <li>Turn around time <strong>15</strong> hours</li>
                  <li>Team of Expert Designers &amp; Developers</li>
                  <li><strong>12</strong> Royalty Free Stock Images</li>
                  <li><strong>8</strong> Website Banner Designs</li>
                  <li>Custom Forms</li>
                  <li>Search Engine Submission</li>
                  <li>Shopping Cart Integration</li>
                  <li>Payment Module Integration</li>
                  <li>Shipping Module Integration</li>
                  <li>Multiple Currency Support</li>
                  <li>Customer Login Area (Sign-Up &amp; Sign-In)</li>
                  <li>Turn around time 15 Hours</li>
                  <li>Complete W3C Certified HTML</li>
                  <li><strong>1</strong> Stationery Design Set (Business card, Letterhead, Envelop &amp; Email Signature)</li>
                  <li>Social Media Designs (Facebook, Twitter, Youtube)</li>
                  <li><strong>FREE</strong> Google Friendly Sitemap</li>
                  <li><strong>FREE</strong> 1 Year Domain &amp; Hosting</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee*</li>
                  <li>Turn around time <strong>15</strong> Hours</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 973 265 7199</a>
              <div class="addnotes ">
                <p>Let's Create</p>
              
              
            </div>
          </div>
        </div>
      </div>